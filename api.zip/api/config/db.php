<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=maplaos_db',
    'username' => 'root',
    'password' => 'Da123!@#',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60000,
    //'schemaCache' => 'cache',
];
